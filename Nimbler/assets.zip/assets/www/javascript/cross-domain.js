		$(document).on("mobileinit", function(){
	  //apply overrides here
	  $.mobile.allowCrossDomainPages = true;
	  $.support.cors = true;
	
	});